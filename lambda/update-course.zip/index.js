exports.handler = async (event) => {
    const courseData = JSON.parse(event.body || "{}");
    return {
        statusCode: 200,
        body: JSON.stringify({ message: "Course updated successfully", data: courseData }),
    };
};