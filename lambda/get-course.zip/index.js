exports.handler = async (event) => {
    const courseId = event.pathParameters?.id || "unknown";
    return {
        statusCode: 200,
        body: JSON.stringify({ message: `Course with ID ${courseId} fetched` }),
    };
};